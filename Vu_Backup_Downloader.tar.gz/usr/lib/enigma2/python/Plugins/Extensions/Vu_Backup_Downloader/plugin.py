# -*- coding: utf-8 -*-
from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.Label import Label
from Components.ActionMap import ActionMap
from Components.MenuList import MenuList
from Components.ProgressBar import ProgressBar
from Components.Console import Console
import os

DOWNLOAD_PATH = "/media/hdd/khaled_vu_download"
WHITELIST_URL = "https://raw.githubusercontent.com/KhaledAli65/books/refs/heads/main/whitelist.txt"
TMP_CHECK = "/tmp/vuplus_check.txt"

class VuPlusBackupDownloader(Screen):
    skin = """
    <screen name="VuPlusBackupDownloader" position="center,center" size="700,550" title="Khaled System Professional v1.5">
        <widget name="device_info" position="20,10" size="660,40" font="Regular;24" halign="center" foregroundColor="#0000ff" />
        <widget name="mac_info" position="20,50" size="660,40" font="Regular;22" halign="center" foregroundColor="#ffffff" />
        <widget name="menu" position="20,100" size="660,250" scrollbarMode="showOnDemand" font="Regular;24" itemHeight="45" />
        <widget name="progress" position="50,370" size="600,25" borderWidth="2" borderColor="#cccccc" />
        <widget name="status" position="20,410" size="660,110" font="Regular;22" halign="center" valign="center" foregroundColor="#00ffcc00" />
    </screen>"""

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        self.list = ["Open atv", "Open bh", "Open vix", "Egami", "Pure2"]
        self["menu"] = MenuList(self.list)
        self["device_info"] = Label("Checking Model...")
        self["mac_info"] = Label("Reading MAC...")
        self["status"] = Label("Verifying Server...")
        self["progress"] = ProgressBar()
        self["progress"].setValue(0)
        self.console = Console()
        self.is_allowed = False
        self.my_mac = self.get_mac_address()

        if not os.path.exists(DOWNLOAD_PATH):
            try: os.makedirs(DOWNLOAD_PATH)
            except: pass

        self.detect_vu_model()
        self["mac_info"].setText("MAC Address: %s" % self.my_mac)
        self.run_final_check()

        self["actions"] = ActionMap(["OkCancelActions"], {
            "ok": self.confirmDownload,
            "cancel": self.close,
        }, -1)

    def get_mac_address(self):
        for interface in ['eth0', 'wlan0', 'ra0', 'eth1']:
            try:
                path = '/sys/class/net/%s/address' % interface
                if os.path.exists(path):
                    mac = open(path).read().strip().upper()
                    if mac and mac != "00:00:00:00:00:00": return mac
            except: pass
        return "00:00:00:00:00:00"

    def run_final_check(self):
        if os.path.exists(TMP_CHECK): os.remove(TMP_CHECK)
        cmd = "wget --no-check-certificate -qO %s %s" % (TMP_CHECK, WHITELIST_URL)
        self.console.ePopen(cmd, self.verifyFile)

    def verifyFile(self, result, retval, extra_args=None):
        if os.path.exists(TMP_CHECK):
            with open(TMP_CHECK, "r") as f:
                allowed_data = f.read().upper()
            if self.my_mac in allowed_data:
                self.is_allowed = True
                self["status"].setText("✅ Verified Successfully!")
            else:
                self.session.openWithCallback(self.close, MessageBox, "MAC Not Authorized!", MessageBox.TYPE_ERROR)
            if os.path.exists(TMP_CHECK): os.remove(TMP_CHECK)

    def detect_vu_model(self):
        self.my_device = "vuplus"
        if os.path.exists("/proc/stb/info/model"):
            self.my_device = open("/proc/stb/info/model").read().strip().lower()
        self["device_info"].setText("Device: Vu+ %s" % self.my_device.upper())

    def confirmDownload(self):
        if not self.is_allowed: return
        selection = self["menu"].getCurrent()
        self.session.openWithCallback(self.startDownload, MessageBox, "Download %s?" % selection, MessageBox.TYPE_YESNO)

    def startDownload(self, answer):
        if not answer: return
        selection = self["menu"].getCurrent()
        
        links = {
            "Open atv": {
                "duo4kse": "https://github.com/KhaledAli65/books/releases/download/Vuduo4kse/openatv-vuduo4kse.zip", 
                "uno4kse": "https://github.com/KhaledAli65/books/releases/download/Vuuno4kse/openatv-vuuno4kse.zip", 
                "zero4k": "https://github.com/KhaledAli65/books/releases/download/Vuzero4k/openatv-vuzero4k.zip", 
                "ultimo4k": "https://github.com/KhaledAli65/books/releases/download/Vuultimo4k/openatv-vuultimo4k.zip", 
                "solo4k": "https://github.com/KhaledAli65/books/releases/download/Vusolo4k/openatv-vusolo4k.zip", 
                "duo4k": "https://github.com/KhaledAli65/books/releases/download/Vuduo4k/openatv-vuduo4k.zip", 
                "uno4k": "https://github.com/KhaledAli65/books/releases/download/Vuuno4k/openatv-vuuno4k.zip"
            },
            "Open bh": {
                "duo4kse": "https://github.com/KhaledAli65/books/releases/download/Vuduo4kse/openbh-vuduo4kse.zip", 
                "uno4kse": "https://github.com/KhaledAli65/books/releases/download/Vuuno4kse/openbh-vuuno4kse.zip", 
                "zero4k": "https://github.com/KhaledAli65/books/releases/download/Vuzero4k/openbh-vuzero4k.zip", 
                "ultimo4k": "https://github.com/KhaledAli65/books/releases/download/Vuultimo4k/openbh-vuultimo4k.zip", 
                "solo4k": "https://github.com/KhaledAli65/books/releases/download/Vusolo4k/openbh-vusolo4k.zip", 
                "duo4k": "https://github.com/KhaledAli65/books/releases/download/Vuduo4k/openbh-vuduo4k.zip", 
                "uno4k": "https://github.com/KhaledAli65/books/releases/download/Vuuno4k/openbh-vuuno4k.zip"
            },
            "Open vix": {
                "duo4kse": "https://github.com/KhaledAli65/books/releases/download/Vuduo4kse/openvix-vuduo4kse.zip", 
                "uno4kse": "https://github.com/KhaledAli65/books/releases/download/Vuuno4kse/openvix-vuuno4kse.zip", 
                "zero4k": "https://github.com/KhaledAli65/books/releases/download/Vuzero4k/openvix-vuzero4k.zip", 
                "ultimo4k": "https://github.com/KhaledAli65/books/releases/download/Vuultimo4k/openvix-vuultimo4k.zip", 
                "solo4k": "https://github.com/KhaledAli65/books/releases/download/Vusolo4k/openvix-vusolo4k.zip", 
                "duo4k": "https://github.com/KhaledAli65/books/releases/download/Vuduo4k/openvix-vuduo4k.zip", 
                "uno4k": "https://github.com/KhaledAli65/books/releases/download/Vuuno4k/openvix-vuuno4k.zip"
            },
            "Egami": {
                "duo4kse": "https://github.com/KhaledAli65/books/releases/download/Vuduo4kse/egami-vuduo4kse.zip", 
                "uno4kse": "https://github.com/KhaledAli65/books/releases/download/Vuuno4kse/egami-vuuno4kse.zip", 
                "zero4k": "https://github.com/KhaledAli65/books/releases/download/Vuzero4k/egami-vuzero4k.zip", 
                "ultimo4k": "https://github.com/KhaledAli65/books/releases/download/Vuultimo4k/egami-vuultimo4k.zip", 
                "solo4k": "https://github.com/KhaledAli65/books/releases/download/Vusolo4k/egami-vusolo4k.zip", 
                "duo4k": "https://github.com/KhaledAli65/books/releases/download/Vuduo4k/egami-vuduo4k.zip", 
                "uno4k": "https://github.com/KhaledAli65/books/releases/download/Vuuno4k/openspa-vuuno4k.zip"
            },
            "Pure2": {
                "duo4kse": "https://github.com/KhaledAli65/books/releases/download/Vuduo4kse/vuduo4kse-PurE2.zip", 
                "uno4kse": "https://github.com/KhaledAli65/books/releases/download/Vuuno4kse/PurE2-vuuno4kse.zip", 
                "zero4k": "https://github.com/KhaledAli65/books/releases/download/Vuzero4k/PurE2-vuzero4k.zip", 
                "ultimo4k": "https://github.com/KhaledAli65/books/releases/download/Vuultimo4k/PurE2-vuultimo4k.zip", 
                "solo4k": "https://github.com/KhaledAli65/books/releases/download/Vusolo4k/PurE2-vusolo4k.zip", 
                "duo4k": "https://github.com/KhaledAli65/books/releases/download/Vuduo4k/vuduo4k-PurE2.zip", 
                "uno4k": "https://github.com/KhaledAli65/books/releases/download/Vuuno4k/vuuno4k-PurE2.zip"
            }
        }

        url = links[selection].get(self.my_device, "")
        if url:
            full_path = os.path.join(DOWNLOAD_PATH, selection.replace(" ", "_") + ".zip")
            self["progress"].setValue(20)
            self["status"].setText("🚀 Downloading...")
            cmd = "wget --no-check-certificate -L -c '%s' -O '%s'" % (url, full_path)
            self.console.ePopen(cmd, self.downloadFinished)
        else:
            self.session.open(MessageBox, "File not found for this device.", MessageBox.TYPE_ERROR)

    def downloadFinished(self, result, retval, extra_args=None):
        self["progress"].setValue(100 if retval == 0 else 0)
        self["status"].setText("✅ Success!" if retval == 0 else "❌ Failed!")

def main(session, **kwargs):
    session.open(VuPlusBackupDownloader)

def Plugins(**kwargs):
    return [PluginDescriptor(
        name="Khaled System Professional",
        description="سيرفر باكابات فيوبلس الحصري",
        where=PluginDescriptor.WHERE_PLUGINMENU,
        icon="plugin.png", # تأكد من وجود هذا السطر كما هو
        fnc=main)]

