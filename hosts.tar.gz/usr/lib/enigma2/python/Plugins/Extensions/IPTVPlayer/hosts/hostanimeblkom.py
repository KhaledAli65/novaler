# -*- coding: utf-8 -*-
# Coding: BY MOHAMED_OS


from Plugins.Extensions.IPTVPlayer.components.ihost import (CBaseHostClass,
                                                            CHostBase)
from Plugins.Extensions.IPTVPlayer.components.iptvplayerinit import \
    TranslateTXT as _
from Plugins.Extensions.IPTVPlayer.libs import ph
from Plugins.Extensions.IPTVPlayer.libs.pCommon import getDefaultHeader
from Plugins.Extensions.IPTVPlayer.libs.urlparser import urlparser
from Plugins.Extensions.IPTVPlayer.p2p3.UrlLib import urllib_quote_plus
from Plugins.Extensions.IPTVPlayer.tools.iptvtools import printDBG, printExc


def gettytul():
    return 'AnimeBlkom'


class AnimeBlkom(CBaseHostClass, urlparser):

    def __init__(self):
        CBaseHostClass.__init__(self, {'history': 'animeblkom', 'cookie': 'animeblkom.net.cookie'})

        self.MAIN_URL = 'https://animeblkom.net/'
        self.DEFAULT_ICON_URL = 'https://i.ibb.co/9pkk1cn/animeblkom.png'

        self.HEADER = getDefaultHeader()
        self.AJAX_HEADER = self.HEADER
        self.AJAX_HEADER.update({'X-Requested-With': 'XMLHttpRequest'})
        self.defaultParams = {'header': self.HEADER, 'use_cookie': True, 'load_cookie': True, 'save_cookie': True, 'cookiefile': self.COOKIE_FILE}
        self.cacheLinks = {}

    def listMainMenu(self, cItem):
        printDBG("AnimeBlkom.listMainMenu")
        MAIN_CAT_TAB = [
            {'category': 'show_list', 'title': _('الأفــلام'), 'icon': self.DEFAULT_ICON_URL, 'url': self.getFullUrl('/movie-list')},
            {'category': 'show_list', 'title': _('مسلـسـلات'), 'icon': self.DEFAULT_ICON_URL, 'url': self.getFullUrl('/series-list')},
            {'category': 'show_list', 'title': _('قائمة الحلقات خاصة'), 'icon': self.DEFAULT_ICON_URL, 'url': self.getFullUrl('/special-list')},
            {'category': 'show_list', 'title': _('قائمة الأوفا'), 'icon': self.DEFAULT_ICON_URL, 'url': self.getFullUrl('/ova-list')},
            {'category': 'show_list', 'title': _('قائمة الأونا'), 'icon': self.DEFAULT_ICON_URL, 'url': self.getFullUrl('/ona-list')},
            {'category': 'search', 'title': _('Search'), 'search_item': True},
            {'category': 'search_history', 'title': _('Search history'), }]
        self.listsTab(MAIN_CAT_TAB, cItem)

    def listItems(self, cItem):
        printDBG("AnimeBlkom.listItems cItem[%s]" % (cItem))
        page = cItem.get('page', 1)

        sts, data = self.cm.getPage(cItem['url'])
        if not sts:
            return

        nextPage = self.cm.ph.getDataBeetwenMarkers(data, ('pagination', '>'), '</nav>', True)[1]
        nextPage = self.getFullUrl(self.cm.ph.getSearchGroups(nextPage, '''href=['"]([^"^']+?)['"] rel=['"]next['"]''')[0])

        tmp = self.cm.ph.getDataBeetwenMarkers(data, ('list-section grid-view', '>'), ('<ul', 'pagination'), True)[1]
        tmp = self.cm.ph.getAllItemsBeetwenMarkers(tmp, ('<div', 'poster'), ('content-inner', '>'))
        for item in tmp:
            icon = self.getFullIconUrl(self.cm.ph.getSearchGroups(item, '''data-original=['"]([^"^']+?)['"]''')[0])
            url = self.getFullUrl(self.cm.ph.getSearchGroups(item, '''<a href=['"]([^"^']+?)['"]''')[0])
            title = self.cleanHtmlStr(self.cm.ph.getSearchGroups(item, '''alt=['"]([^"^']+?)['"]''')[0])
            desc = self.cleanHtmlStr(self.cm.ph.getDataBeetwenNodes(item, ('story-text', '>'), '</p>', False)[1])

            if title != '':
                title = ph.std_title(title, with_ep=True)['title_display']

            params = dict(cItem)
            params.update({'category': 'listItems', 'good_for_fav': True, 'EPG': True, 'title': title, 'url': self.getFullUrl(url), 'icon': ph.std_url(icon), 'desc': desc})
            self.addDir(params)

        if nextPage != '':
            params = dict(cItem)
            params.update({'title': _("Next page"), 'url': self.getFullUrl(nextPage), 'page': page + 1})
            self.addDir(params)

    def exploreItems(self, cItem):
        printDBG("AnimeBlkom.exploreItems cItem[%s]" % (cItem))

        sts, data = self.cm.getPage(cItem['url'])
        if not sts:
            return

        # trailer
        trailerUrl = self.cm.ph.getDataBeetwenMarkers(data, ('modal-header', '>'), '</iframe>')[1]
        trailerUrl = self.cm.ph.getSearchGroups(trailerUrl, '''data-src=['"]([^"^']+?)['"]''')[0]
        if self.cm.isValidUrl(trailerUrl):
            params = dict(cItem)
            params.update({'good_for_fav': False, 'title': '[\c00???020Trailer\c00??????]', 'url': trailerUrl, 'desc': ''})
            self.addVideo(params)

        tmp = self.cm.ph.getDataBeetwenMarkers(data, ('episode-link ', '>'), ('adblock container', '>'), True)[1]
        tmp_ = self.cm.ph.getAllItemsBeetwenMarkers(tmp, '<a ', '</a>')
        for item in tmp_:
            url = ph.std_url(self.getFullUrl(self.cm.ph.getSearchGroups(item, '''href=['"]([^"^']+?)['"]''')[0]))
            title = self.cleanHtmlStr(self.cm.ph.getDataBeetwenMarkers(item, '<span>', '</a>', True)[1]).replace(':', '')

            if title != '':
                title = ph.std_title(title, with_ep=True)['title_display']

            params = dict(cItem)
            params.update({'good_for_fav': True, 'EPG': True, 'title': title, 'url': url, 'icon': cItem['icon'], 'desc': cItem['desc']})
            self.addVideo(params)

    def listSearchResult(self, cItem, searchPattern, searchType):
        printDBG("AnimeBlkom.listSearchResult cItem[%s], searchPattern[%s] searchType[%s]" % (cItem, searchPattern, searchType))
        url = self.getFullUrl('/search?query={}'.format(urllib_quote_plus(searchPattern)))
        params = {'name': 'category', 'category': 'list_items', 'good_for_fav': False, 'url': url}
        self.listItems(params)

    def getLinksForVideo(self, cItem):
        printDBG("AnimeBlkom.getLinksForVideo [%s]" % cItem)
        urlTab = []

        if 1 == self.up.checkHostSupport(cItem['url']):
            return self.up.getVideoLinkExt(cItem['url'])

        sts, data = self.cm.getPage(cItem['url'])
        if not sts:
            return

        tmp = self.cm.ph.getDataBeetwenMarkers(data, ('servers-label', '>'), ('video-container', '>'), True)[1]
        tmp = self.cm.ph.getAllItemsBeetwenMarkers(tmp, ('item', '>'), ('next-tab', '>'))
        for item in tmp:
            url = self.getFullUrl(self.cm.ph.getSearchGroups(item, '''data-src=['"]([^"^']+?)['"]''')[0])
            title = self.cleanHtmlStr(self.cm.ph.getSearchGroups(item, '''data-src.+>([^>]+?)</''')[0])

            if title != '':
                title = ('{} \c00??7950 [{}]\c00??????\c00???020 - {}\c00??????'.format(ph.std_title(cItem['title'], with_ep=True)['title_display'], title, self.getHostName(url, True)))

            urlTab.append({'name': title, 'url': url, 'need_resolve': 1})

        return urlTab

    def getVideoLinks(self, videoUrl):
        printDBG("AnimeBlkom.getVideoLinks [%s]" % videoUrl)

        return self.up.getVideoLinkExt(videoUrl)

    def getArticleContent(self, cItem):
        printDBG("AnimeBlkom.getArticleContent [%s]" % cItem)
        otherInfo = {}

        sts, data = self.cm.getPage(cItem['url'])
        if not sts:
            return

        tmp = self.cm.ph.getDataBeetwenMarkers(data, ('pull-right story-column', '>'), (' pull-right list-column', '>'), True)[1]

        title = self.cleanHtmlStr(self.cm.ph.getDataBeetwenNodes(tmp, ('<span>', '<h1>'), '<small>', False)[1])
        desc = self.cleanHtmlStr(self.cm.ph.getDataBeetwenNodes(tmp, ('story', '>'), ('</div>', '</div>'), False)[1])

        if title == '':
            title = cItem['title']
        if desc == '':
            desc = cItem['desc']

        return [{'title': self.cleanHtmlStr(title), 'text': self.cleanHtmlStr(desc), 'images': [{'title': '', 'url': self.getFullUrl(cItem['icon'])}], 'other_info': otherInfo}]

    def handleService(self, index, refresh=0, searchPattern='', searchType=''):
        printDBG('handleService start')

        CBaseHostClass.handleService(self, index, refresh, searchPattern, searchType)

        name = self.currItem.get("name", '')
        category = self.currItem.get("category", '')
        printDBG("handleService: |||||||||||||||||||||||||||||||||||| name[%s], category[%s] " % (name, category))
        self.currList = []

        # MAIN MENU
        if name is None and category == '':
            self.listMainMenu({'name': 'category', 'type': 'category'})
        elif category == 'show_list':
            self.listItems(self.currItem)
        elif category == 'listItems':
            self.exploreItems(self.currItem)
    # SEARCH
        elif category in ["search", "search_next_page"]:
            cItem = dict(self.currItem)
            cItem.update({'search_item': False, 'name': 'category'})
            self.listSearchResult(cItem, searchPattern, searchType)
    # HISTORIA SEARCH
        elif category == "search_history":
            self.listsHistory({'name': 'history', 'category': 'search'}, 'desc', _("Type: "))
        else:
            printExc()

        CBaseHostClass.endHandleService(self, index, refresh)


class IPTVHost(CHostBase):

    def __init__(self):
        CHostBase.__init__(self, AnimeBlkom(), True, [])

    def withArticleContent(self, cItem):
        if cItem['type'] != 'video' and cItem['category'] != 'exploreItems':
            return False
        return True
