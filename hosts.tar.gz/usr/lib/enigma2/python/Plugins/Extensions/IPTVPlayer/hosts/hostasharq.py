# -*- coding: utf-8 -*-
# Coding: BY MOHAMED_OS

import re

from Plugins.Extensions.IPTVPlayer.components.ihost import (CBaseHostClass,
                                                            CHostBase)
from Plugins.Extensions.IPTVPlayer.components.iptvplayerinit import \
    TranslateTXT as _
from Plugins.Extensions.IPTVPlayer.libs import ph
from Plugins.Extensions.IPTVPlayer.libs.pCommon import getDefaultHeader
from Plugins.Extensions.IPTVPlayer.tools.iptvtools import printDBG, printExc


def gettytul():
    return 'Asharq'


class Asharq(CBaseHostClass):

    def __init__(self):
        CBaseHostClass.__init__(self, {'cookie': 'asharq.com.cookie'})

        self.HEADER = getDefaultHeader()
        self.AJAX_HEADER = self.HEADER
        self.AJAX_HEADER.update({'X-Requested-With': 'XMLHttpRequest'})
        self.defaultParams = {'header': self.HEADER, 'use_cookie': True, 'load_cookie': True, 'save_cookie': True, 'cookiefile': self.COOKIE_FILE}

        self.MAIN_URL = 'https://now.asharq.com/'
        self.DEFAULT_ICON_URL = 'https://i.ibb.co/xsbdc1f/asharq.png'

    def listMainMenu(self, cItem):
        printDBG("Asharq.listMainMenu")
        MAIN_CAT_TAB = [
            {'category': 'show_movies', 'title': _('افـلام وثائقية'), 'icon': self.DEFAULT_ICON_URL, 'url': self.getFullUrl('/doc/')},
            {'category': 'show_movies', 'title': _('أفـلام الاكــتشاف'), 'icon': self.DEFAULT_ICON_URL, 'url': self.getFullUrl('/discovery/')},
            {'category': 'show_list', 'title': _('بـودكــاسـت'), 'icon': self.DEFAULT_ICON_URL, 'url': ph.std_url(self.getFullUrl('/الشرق-بودكاست/'))},
            {'category': 'show_list', 'title': _('QuickTake'), 'icon': self.DEFAULT_ICON_URL, 'url': ph.std_url(self.getFullUrl('/الشرق-quicktake/'))},
            {'category': 'show_list', 'title': _('اقـتصـاد'), 'icon': self.DEFAULT_ICON_URL, 'url': ph.std_url(self.getFullUrl('/اقتصاد-الشرق/'))}]
        self.listsTab(MAIN_CAT_TAB, cItem)

    def listItems(self, cItem):
        printDBG("Asharq.listItems cItem[%s]" % (cItem))

        sts, data = self.cm.getPage(cItem['url'])
        if not sts:
            return

        tmp = self.cm.ph.getDataBeetwenMarkers(data, ('<main', '>'), '</main>', True)[1]
        tmp = self.cm.ph.getAllItemsBeetwenMarkers(tmp, ('card', 'card-genre-'), ('swiper-slide', 'is-column-4'))
        for item in tmp:
            icon = ph.std_url(self.getFullIconUrl(self.cm.ph.getSearchGroups(item, '''src=['"]([^"^']+?)['"]''')[0]))
            url = ph.std_url(self.getFullUrl(self.cm.ph.getSearchGroups(item, '''href=['"]([^"^']+?)['"]''')[0]))
            title = self.cleanHtmlStr(self.cm.ph.getSearchGroups(item, '''alt=['"]([^"^']+?)['"]''')[0])
            desc = self.cleanHtmlStr(self.cm.ph.getDataBeetwenNodes(item, ('card-description', '>'), ('</p', '>'), False)[1])

            params = dict(cItem)
            params.update({'category': 'listItems', 'good_for_fav': True, 'EPG': True, 'title': title, 'url': url, 'icon': icon, 'desc': desc})
            self.addDir(params)

    def exploreItems(self, cItem):
        printDBG("Asharq.exploreItems cItem[%s]" % (cItem))

        sts, data = self.cm.getPage(cItem['url'])
        if not sts:
            return

        if '<div class="cards-list">' in data:
            tmp = self.cm.ph.getDataBeetwenMarkers(data, ('<section', '>'), ('</section', 'content-type-component'), True)[1]
            tmp = self.cm.ph.getAllItemsBeetwenMarkers(tmp, ('card', 'genre-episode'), ('<div', 'card-item'))
            for item in tmp:
                icon = ph.std_url(self.getFullIconUrl(self.cm.ph.getSearchGroups(item, '''src=['"]([^"^']+?)['"]''')[0]))
                url = ph.std_url(self.getFullUrl(self.cm.ph.getSearchGroups(item, '''href=['"]([^"^']+?)['"]''')[0]))
                title = self.cleanHtmlStr(self.cm.ph.getSearchGroups(item, '''alt=['"]([^"^']+?)['"]''')[0])
                desc = self.cleanHtmlStr(self.cm.ph.getDataBeetwenNodes(item, ('card-shortdescription', '>'), ('</p', '>'), False)[1])

                params = dict(cItem)
                params.update({'good_for_fav': True, 'EPG': True, 'title': title, 'url': url, 'icon': icon, 'desc': desc})
                self.addVideo(params)
        else:
            params = dict(cItem)
            params.update({'good_for_fav': True, 'EPG': True, 'title': cItem['title'], 'url': cItem['url'], 'icon': cItem['icon'], 'desc': cItem['desc']})
            self.addVideo(params)

    def getLinksForVideo(self, cItem):
        printDBG("Asharq.getLinksForVideo [%s]" % cItem)
        urlTab = []

        sts, data = self.cm.getPage(cItem['url'])
        if not sts:
            return

        tmp = self.cm.ph.getDataBeetwenMarkers(data, 'advertisement', 'omidVendor', True)[1]
        result = re.findall(''',['"]Link['"]:.+?},['"](.+?)['"],['"](.+?)['"],''', tmp, re.S)
        for (title, url) in result:
            urlTab.append({'name': title, 'url': url, 'need_resolve': 0})
        return urlTab

    def getVideoLinks(self, videoUrl):
        printDBG("Asharq.getVideoLinks [%s]" % videoUrl)

        return self.up.getVideoLinkExt(videoUrl)

    def getArticleContent(self, cItem):
        printDBG("Asharq.getArticleContent [%s]" % cItem)
        otherInfo = {}

        sts, data = self.cm.getPage(cItem['url'])
        if not sts:
            return

        tmp = self.cm.ph.getDataBeetwenMarkers(data, ('card-content-hover', '>'), ('</span', '</a'), True)[1]
        desc = self.cleanHtmlStr(self.cm.ph.getDataBeetwenNodes(tmp, ('card-description', '>'), ('</p', '</div>'), False)[1])

        if desc == '':
            desc = cItem['desc']

        title = cItem['title']
        icon = cItem['icon']

        return [{'title': self.cleanHtmlStr(title), 'text': self.cleanHtmlStr(desc), 'images': [{'title': '', 'url': self.getFullUrl(icon)}], 'other_info': otherInfo}]

    def handleService(self, index, refresh=0, searchPattern='', searchType=''):
        printDBG('handleService start')

        CBaseHostClass.handleService(self, index, refresh, searchPattern, searchType)

        name = self.currItem.get("name", '')
        category = self.currItem.get("category", '')
        printDBG("handleService: |||||||||||||||||||||||||||||||||||| name[%s], category[%s] " % (name, category))
        self.currList = []

        # MAIN MENU
        if name is None and category == '':
            self.listMainMenu({'name': 'category', 'type': 'category'})
        elif category == 'show_movies':
            self.listItems(self.currItem)
        elif category == 'show_list':
            self.listItems(self.currItem)
        elif category == 'listItems':
            self.exploreItems(self.currItem)
        else:
            printExc()

        CBaseHostClass.endHandleService(self, index, refresh)


class IPTVHost(CHostBase):

    def __init__(self):
        CHostBase.__init__(self, Asharq(), True, [])

    def withArticleContent(self, cItem):
        if cItem['type'] != 'video' and cItem['category'] != 'exploreItems':
            return False
        return True
