# -*- coding: utf-8 -*-
from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Components.MenuList import MenuList
from Components.ActionMap import ActionMap
from Components.Label import Label
from Screens.MessageBox import MessageBox
from Screens.Standby import TryQuitMainloop
import shutil
import os

class KhaledUninstallerMain(Screen):
    skin = """
    <screen name="KhaledUninstallerMain" position="center,center" size="700,450" title="Khaled World Uninstaller">
        <widget name="menu" position="20,20" size="660,320" font="Regular;30" itemHeight="60" scrollbarMode="showOnDemand" />
        <widget name="key_red" position="20,380" size="150,40" font="Regular;22" halign="center" valign="center" backgroundColor="#9f1313" transparent="0" />
        <widget name="key_green" position="180,380" size="150,40" font="Regular;22" halign="center" valign="center" backgroundColor="#1f771f" transparent="0" />
    </screen>"""

    def __init__(self, session):
        Screen.__init__(self, session)
        self.menu_options = [
            ("1. Plugins (Extensions)", "/usr/lib/enigma2/python/Plugins/Extensions/"),
            ("2. Skins (Layouts)", "/usr/share/enigma2/"),
            ("3. Clean System (CrashLogs / Tmp)", "CLEAN_LOGS") # الخيار الجديد
        ]
        self["menu"] = MenuList(self.menu_options)
        self["key_red"] = Label("خروج")
        self["key_green"] = Label("دخول")
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"], {
            "ok": self.goIntoFolder,
            "green": self.goIntoFolder,
            "cancel": self.close,
            "red": self.close,
        }, -1)

    def goIntoFolder(self):
        selection = self["menu"].getCurrent()
        if selection:
            if selection[1] == "CLEAN_LOGS":
                self.session.openWithCallback(self.startCleaning, MessageBox, "هل تريد تنظيف ملفات الكراش والملفات المؤقتة الآن؟", MessageBox.TYPE_YESNO)
            else:
                self.session.open(MultiFolderExplorer, str(selection[1]), str(selection[0]))

    def startCleaning(self, answer):
        if answer:
            cleaned_files = 0
            # تنظيف ملفات الكراش في hdd و tmp
            paths_to_clean = ["/hdd/", "/tmp/", "/media/hdd/"]
            for path in paths_to_clean:
                if os.path.exists(path):
                    for f in os.listdir(path):
                        if f.endswith(".log") or "enigma2-crash" in f:
                            try:
                                os.remove(os.path.join(path, f))
                                cleaned_files += 1
                            except: pass
            
            # تنظيف ملفات tmp العامة (ملفات التحميل المؤقتة)
            try:
                for f in os.listdir("/tmp/"):
                    if f.endswith(".ipk") or f.endswith(".tar.gz"):
                        os.remove(os.path.join("/tmp/", f))
                        cleaned_files += 1
            except: pass
            
            self.session.open(MessageBox, "تم تنظيف عدد (%d) ملفات بنجاح!" % cleaned_files, MessageBox.TYPE_INFO)

class MultiFolderExplorer(Screen):
    skin = """
    <screen name="MultiFolderExplorer" position="center,center" size="900,600" title="Khaled Explorer">
        <widget name="list" position="20,20" size="860,450" font="Regular;26" itemHeight="45" scrollbarMode="showOnDemand" />
        <widget name="key_red" position="20,500" size="140,40" font="Regular;22" halign="center" valign="center" backgroundColor="#9f1313" />
        <widget name="key_green" position="170,500" size="140,40" font="Regular;22" halign="center" valign="center" backgroundColor="#1f771f" />
        <widget name="key_blue" position="320,500" size="140,40" font="Regular;22" halign="center" valign="center" backgroundColor="#18569a" />
        <widget name="status" position="20,550" size="860,30" font="Regular;20" halign="left" foregroundColor="#f0a30a" />
    </screen>"""

    def __init__(self, session, path, title):
        Screen.__init__(self, session)
        self.path = str(path)
        self.selected_folders = []
        self["list"] = MenuList([])
        self["status"] = Label("OK: اختيار | أخضر: حذف | أزرق: ريبوت")
        self["key_red"] = Label("رجوع")
        self["key_green"] = Label("حذف")
        self["key_blue"] = Label("ريبوت")
        
        self.loadFolders()
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"], {
            "ok": self.toggleSelection,
            "green": self.confirmDelete,
            "blue": self.rebootMenu,
            "red": self.close,
            "cancel": self.close,
        }, -1)

    def loadFolders(self):
        display_list = []
        if os.path.exists(self.path):
            try:
                folders = sorted([f for f in os.listdir(self.path) if os.path.isdir(os.path.join(self.path, f))])
                for f in folders:
                    prefix = "[  X  ]   " if f in self.selected_folders else "[       ]   "
                    display_list.append(prefix + f)
            except: pass
        self["list"].setList(display_list)

    def toggleSelection(self):
        current = self["list"].getCurrent()
        if current:
            try:
                folder_name = current.split("]   ")[1]
                if folder_name in self.selected_folders:
                    self.selected_folders.remove(folder_name)
                else:
                    self.selected_folders.append(folder_name)
                self.loadFolders()
            except: pass

    def confirmDelete(self):
        if not self.selected_folders:
            self.session.open(MessageBox, "من فضلك اختر المجلدات أولاً", MessageBox.TYPE_INFO)
            return
        msg = "هل تريد حذف (%d) مجلدات نهائياً؟" % len(self.selected_folders)
        self.session.openWithCallback(self.startDeletion, MessageBox, msg, MessageBox.TYPE_YESNO)

    def startDeletion(self, answer):
        if answer:
            self["status"].setText("جاري الحذف...")
            count = 0
            for folder in self.selected_folders:
                try:
                    shutil.rmtree(os.path.join(self.path, folder))
                    count += 1
                except: pass
            self.selected_folders = []
            self.loadFolders()
            self.session.open(MessageBox, "تم حذف (%d) مجلدات بنجاح" % count, MessageBox.TYPE_INFO)
            self["status"].setText("تم الانتهاء")

    def rebootMenu(self):
        from Screens.ChoiceBox import ChoiceBox
        self.session.openWithCallback(self.executeReboot, ChoiceBox, title="التحكم:", list=[("Restart Enigma2", "gui"), ("Reboot Device", "reboot")])

    def executeReboot(self, choice):
        if choice:
            cmd = 3 if choice[1] == "gui" else 2
            self.session.open(TryQuitMainloop, cmd)

def main(session, **kwargs):
    session.open(KhaledUninstallerMain)

def Plugins(**kwargs):
    return [PluginDescriptor(name="Khaled Uninstaller", description="Bulk Delete & Clean System", where=PluginDescriptor.WHERE_PLUGINMENU, icon="plugin.png", fnc=main)]

