# -*- coding: utf-8 -*-
from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.Label import Label
from Components.ActionMap import ActionMap
from Components.MenuList import MenuList
from Components.ProgressBar import ProgressBar
from Components.Console import Console
import os

DOWNLOAD_PATH = "/media/hdd/khaled_download"
WHITELIST_URL = "https://raw.githubusercontent.com/KhaledAli65/books/refs/heads/main/whitelist.txt"
TMP_CHECK = "/tmp/khaled_check.txt"

class NovalerBackupDownloader(Screen):
    skin = """
    <screen name="NovalerBackupDownloader" position="center,center" size="700,550" title="Khaled Novaler Professional v1.5">
        <widget name="device_info" position="20,10" size="660,40" font="Regular;24" halign="center" foregroundColor="#0000ff" />
        <widget name="mac_info" position="20,50" size="660,40" font="Regular;22" halign="center" foregroundColor="#ffffff" />
        <widget name="menu" position="20,100" size="660,250" scrollbarMode="showOnDemand" font="Regular;24" itemHeight="45" />
        <widget name="progress" position="50,370" size="600,25" borderWidth="2" borderColor="#cccccc" />
        <widget name="status" position="20,410" size="660,110" font="Regular;22" halign="center" valign="center" foregroundColor="#00ffcc00" />
    </screen>"""

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        self.list = ["Egami 11.0", "Open atv", "Open bh", "Open vix", "PurE2"]
        self["menu"] = MenuList(self.list)
        self["device_info"] = Label("جاري فحص الموديل...")
        self["mac_info"] = Label("جاري استخراج الماك...")
        self["status"] = Label("جاري التحقق من السيرفر...")
        self["progress"] = ProgressBar()
        self["progress"].setValue(0)
        self.console = Console()
        self.my_mac = self.get_mac_address()
        self.is_allowed = False

        if not os.path.exists(DOWNLOAD_PATH):
            try: os.makedirs(DOWNLOAD_PATH)
            except: pass

        self.detect_my_device()
        self["mac_info"].setText("الماك أدريس: %s" % self.my_mac)
        
        # تنفيذ التحقق بطريقة الملف المؤقت (أضمن طريقة)
        self.run_final_check()

        self["actions"] = ActionMap(["OkCancelActions"], {
            "ok": self.confirmDownload,
            "cancel": self.close,
        }, -1)

    def get_mac_address(self):
        for interface in ['eth0', 'wlan0', 'ra0', 'eth1', 'wlan1']:
            try:
                path = '/sys/class/net/%s/address' % interface
                if os.path.exists(path):
                    mac = open(path).read().strip().upper()
                    if mac and mac != "00:00:00:00:00:00": return mac
            except: pass
        return "00:00:00:00:00:00"

    def run_final_check(self):
        # حذف الملف المؤقت القديم إن وجد
        if os.path.exists(TMP_CHECK): os.remove(TMP_CHECK)
        # تحميل القائمة لملف مؤقت
        cmd = "wget --no-check-certificate -qO %s %s" % (TMP_CHECK, WHITELIST_URL)
        self.console.ePopen(cmd, self.verifyFile)

    def verifyFile(self, result, retval, extra_args=None):
        if os.path.exists(TMP_CHECK):
            with open(TMP_CHECK, "r") as f:
                allowed_data = f.read().upper()
            
            if self.my_mac in allowed_data:
                self.is_allowed = True
                self["status"].setText("✅ تم التحقق بنجاح! أهلاً بك")
            else:
                self["status"].setText("❌ جهازك غير مسجل")
                self.lock_plugin()
            # تنظيف الملف المؤقت
            os.remove(TMP_CHECK)
        else:
            self["status"].setText("⚠️ فشل الاتصال بالسيرفر (خطأ 404)")

    def lock_plugin(self):
        self.session.openWithCallback(self.close, MessageBox, "جهازك غير مسجل!\nالماك: %s" % self.my_mac, MessageBox.TYPE_ERROR)

    def detect_my_device(self):
        if os.path.exists("/proc/stb/info/model"):
            self.my_device = open("/proc/stb/info/model").read().strip().lower()
        if "multiboxse" in self.my_device: self.display_name = "Novaler Multibox 4K SE"
        elif "multibox" in self.my_device: self.display_name = "Novaler Multibox 4K"
        elif "pro" in self.my_device: self.display_name = "Novaler 4K Pro"
        self["device_info"].setText("جهازك: %s" % self.display_name)

    def confirmDownload(self):
        if not self.is_allowed:
            self.run_final_check() # محاولة تحقق أخيرة
            return
        selection = self["menu"].getCurrent()
        self.session.openWithCallback(self.startDownload, MessageBox, "بدء تحميل %s؟" % selection, MessageBox.TYPE_YESNO)

    def startDownload(self, answer):
        if not answer: return
        selection = self["menu"].getCurrent()
        links = {
            "Egami 11.0": {"multiboxse": "https://github.com/KhaledAli65/books/releases/download/Novalerse/egami-11.0-novaler4kse.zip", "multibox": "https://github.com/KhaledAli65/books/releases/download/Novaler4k/egami-novaler4k.zip", "pro": "https://github.com/KhaledAli65/books/releases/download/Novalerpro/egami-novaler4kpro.zip"},
            "Open atv": {"multibox": "https://github.com/KhaledAli65/books/releases/download/Novaler4k/openatv-novaler4k.zip", "multiboxse": "https://github.com/KhaledAli65/books/releases/download/Novalerse/openatv-novaler4kse.zip", "pro": "https://github.com/KhaledAli65/books/releases/download/Novalerpro/openatv-novaler4kpro.zip"},
            "Open bh": {"multibox": "https://github.com/KhaledAli65/books/releases/download/Novaler4k/openbh-novaler4k.zip", "multiboxse": "https://github.com/KhaledAli65/books/releases/download/Novalerse/openbh-novaler4kse.zip", "pro": "https://github.com/KhaledAli65/books/releases/download/Novalerpro/openbh-novaler4kpro.zip"},
            "Open vix": {"multibox": "https://github.com/KhaledAli65/books/releases/download/Novaler4k/openvix-novaler4k.zip", "multiboxse": "https://github.com/KhaledAli65/books/releases/download/Novalerse/openvix-novaler4kse.zip", "pro": "https://github.com/KhaledAli65/books/releases/download/Novalerpro/openvix-novaler4kpro.zip"},
            "PurE2": {"multibox": "https://github.com/KhaledAli65/books/releases/download/Novaler4k/novaler4k-PurE2.zip", "multiboxse": "https://github.com/KhaledAli65/books/releases/download/Novalerse/pure2-novaler4kse.zip", "pro": "https://github.com/KhaledAli65/books/releases/download/Novalerpro/novaler4kpro-PurE2.zip"}
        }
        url = links[selection].get(self.my_device)
        if url:
            full_path = os.path.join(DOWNLOAD_PATH, selection.replace(" ","_") + ".zip")
            self["status"].setText("🚀 جاري التحميل...")
            self.console.ePopen("wget --no-check-certificate '%s' -O '%s'" % (url, full_path), self.downloadFinished)

    def downloadFinished(self, result, retval, extra_args=None):
        self["status"].setText("✅ اكتمل التحميل!" if retval == 0 else "❌ فشل التحميل")

def main(session, **kwargs):
    session.open(NovalerBackupDownloader)

def Plugins(**kwargs):
    return [PluginDescriptor(name="Khaled Novaler Professional", where=PluginDescriptor.WHERE_PLUGINMENU, icon="plugin.png", fnc=main)]

