# -*- coding: utf-8 -*-
from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox # إضافة مكتبة الرسائل
from Components.Label import Label
from Components.ActionMap import ActionMap
from Components.MenuList import MenuList
from Components.ProgressBar import ProgressBar
from Components.Console import Console
import os

# مسار الحفظ المعتمد
DOWNLOAD_PATH = "/media/hdd/khaled_download"

class NovalerBackupDownloader(Screen):
    skin = """
    <screen name="NovalerBackupDownloader" position="center,center" size="700,500" title="Khaled Novaler Downloader v1.0">
        <widget name="device_info" position="20,10" size="660,40" font="Regular;24" halign="center" foregroundColor="#0000ff" />
        <widget name="menu" position="20,60" size="660,250" scrollbarMode="showOnDemand" font="Regular;24" itemHeight="45" />
        <widget name="progress" position="50,330" size="600,25" borderWidth="2" borderColor="#cccccc" />
        <widget name="status" position="20,370" size="660,110" font="Regular;22" halign="center" valign="center" foregroundColor="#00ffcc00" />
    </screen>"""

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        self.list = ["Egami 11.0", "Open atv", "Open bh", "Open vix", "PurE2"]
        self["menu"] = MenuList(self.list)
        self["device_info"] = Label("جاري فحص موديل الجهاز...")
        self["status"] = Label("اختر الملف واضغط OK لبدء التحميل 🚀")
        self["progress"] = ProgressBar()
        self["progress"].setValue(0)
        self.console = Console()
        self.my_device = "unknown"
        self.display_name = "Novaler" # متغير لحفظ اسم الجهاز للعرض

        if not os.path.exists(DOWNLOAD_PATH):
            try: os.makedirs(DOWNLOAD_PATH)
            except: pass

        self.detect_my_device()

        self["actions"] = ActionMap(["OkCancelActions"], {
            "ok": self.confirmDownload, # تغيير التوجيه لرسالة التأكيد أولاً
            "cancel": self.close,
        }, -1)

    def detect_my_device(self):
        if os.path.exists("/proc/stb/info/model"):
            with open("/proc/stb/info/model", "r") as f:
                self.my_device = f.read().strip().lower()
        
        if "multiboxse" in self.my_device: self.display_name = "Novaler Multibox 4K SE"
        elif "multibox" in self.my_device: self.display_name = "Novaler Multibox 4K"
        elif "pro" in self.my_device: self.display_name = "Novaler 4K Pro"
        self["device_info"].setText("جهازك المكتشف: %s" % self.display_name)

    def confirmDownload(self):
        # تظهر هذه الرسالة عند الضغط على OK
        selection = self["menu"].getCurrent()
        message = "لقد اكتشفنا أن جهازك هو: %s\n\nهل تريد تحميل (%s) الآن؟" % (self.display_name, selection)
        self.session.openWithCallback(self.startDownload, MessageBox, message, MessageBox.TYPE_YESNO)

    def startDownload(self, answer):
        if not answer: # إذا اختار المستخدم "No"
            return
            
        selection = self["menu"].getCurrent()
        
        links = {
            "Egami 11.0": {
                "multiboxse": "https://github.com/KhaledAli65/books/releases/download/Novalerse/egami-11.0-novaler4kse.zip",
                "multibox": "https://github.com/KhaledAli65/books/releases/download/Novaler4k/egami-novaler4k.zip",
                "pro": "https://github.com/KhaledAli65/books/releases/download/Novalerpro/egami-novaler4kpro.zip"
            },
            "Open atv": {"multibox": "https://github.com/KhaledAli65/books/releases/download/Novaler4k/openatv-novaler4k.zip", "multiboxse": "https://github.com/KhaledAli65/books/releases/download/Novalerse/openatv-novaler4kse.zip", "pro": "https://github.com/KhaledAli65/books/releases/download/Novalerpro/openatv-novaler4kpro.zip"},
            "Open bh": {"multibox": "https://github.com/KhaledAli65/books/releases/download/Novaler4k/openbh-novaler4k.zip", "multiboxse": "https://github.com/KhaledAli65/books/releases/download/Novalerse/openbh-novaler4kse.zip", "pro": "https://github.com/KhaledAli65/books/releases/download/Novalerpro/openbh-novaler4kpro.zip"},
            "Open vix": {"multibox": "https://github.com/KhaledAli65/books/releases/download/Novaler4k/openvix-novaler4k.zip", "multiboxse": "https://github.com/KhaledAli65/books/releases/download/Novalerse/openvix-novaler4kse.zip", "pro": "https://github.com/KhaledAli65/books/releases/download/Novalerpro/openvix-novaler4kpro.zip"},
            "PurE2": {"multibox": "https://github.com/KhaledAli65/books/releases/download/Novaler4k/novaler4k-PurE2.zip", "multiboxse": "https://github.com/KhaledAli65/books/releases/download/Novalerse/pure2-novaler4kse.zip", "pro": "https://github.com/KhaledAli65/books/releases/download/Novalerpro/novaler4kpro-PurE2.zip"}
        }

        url = links[selection].get(self.my_device)
        if url and url.startswith("http"):
            clean_name = selection.replace(" ", "_") + "_" + self.my_device + ".zip"
            full_path = os.path.join(DOWNLOAD_PATH, clean_name)
            
            # تحديث الواجهة فور بدء التحميل
            self["progress"].setValue(20) 
            self["status"].setText("🚀 جاري التحميل من GitHub سيرفر...\nيرجى الانتظار، الملف سيحفظ في:\n%s" % DOWNLOAD_PATH)
            
            cmd = "wget --no-check-certificate -L -c '%s' -O '%s'" % (url, full_path)
            self.console.ePopen(cmd, self.downloadFinished)
        else:
            self.session.open(MessageBox, "عذراً، هذا الملف غير متوفر لجهازك حالياً على السيرفر", MessageBox.TYPE_ERROR)

    def downloadFinished(self, result, retval, extra_args=None):
        if retval == 0:
            self["progress"].setValue(100)
            self["status"].setText("✅ مبروك! اكتمل التحميل بنجاح.\nيمكنك الآن تنصيب الصورة من الريكفري.")
            self.session.open(MessageBox, "تم التحميل بنجاح!\nالملف موجود في: /media/hdd/khaled_download", MessageBox.TYPE_INFO)
        else:
            self["progress"].setValue(0)
            self["status"].setText("❌ فشل التحميل! تأكد من الهارد ديسك أو الإنترنت.")
            self.session.open(MessageBox, "فشل التحميل! تأكد من وجود مساحة كافية في الهارد ديسك.", MessageBox.TYPE_ERROR)

def main(session, **kwargs):
    session.open(NovalerBackupDownloader)

def Plugins(**kwargs):
    return [PluginDescriptor(
        name="Khaled Novaler Downloader",
        description="تحميل باكابات وصور نوفالير من سيرفرات GitHub العالمية",
        where=PluginDescriptor.WHERE_PLUGINMENU,
        icon="plugin.png",
        fnc=main)]

