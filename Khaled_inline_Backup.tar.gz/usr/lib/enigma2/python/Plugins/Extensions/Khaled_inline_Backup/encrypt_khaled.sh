#!/bin/sh
# سكريبت خالد - الإصدار النهائي للتوافق مع بايثون 3
CURRENT_DIR=$(cd "$(dirname "$0")"; pwd)

echo "🚀 جاري التشفير بنظام الاحتراف..."

if [ -f "$CURRENT_DIR/plugin.py" ]; then
    # تنظيف شامل قبل البدء
    rm -f "$CURRENT_DIR/plugin.pyc" "$CURRENT_DIR/plugin.pyo"
    rm -rf "$CURRENT_DIR/__pycache__"

    # تشفير الملف
    python -m py_compile "$CURRENT_DIR/plugin.py"

    # التعامل مع بايثون 3 (نقل الملف من المجلد المخفي وتغيير اسمه)
    if [ -d "$CURRENT_DIR/__pycache__" ]; then
        cp $CURRENT_DIR/__pycache__/plugin.cpython*.pyc $CURRENT_DIR/plugin.pyc
        rm -rf "$CURRENT_DIR/__pycache__"
        
        # التأكد من وجود الملف الناتج
        if [ -f "$CURRENT_DIR/plugin.pyc" ]; then
            chmod 755 "$CURRENT_DIR/plugin.pyc"
            rm -f "$CURRENT_DIR/plugin.py"
            echo "✅ نجح التشفير (Python 3)! الملف الحالي: plugin.pyc"
        fi
    else
        # إذا كان الجهاز قديم (بايثون 2)
        if [ -f "$CURRENT_DIR/plugin.pyc" ]; then
            mv "$CURRENT_DIR/plugin.pyc" "$CURRENT_DIR/plugin.pyc"
            rm -f "$CURRENT_DIR/plugin.py"
            echo "✅ نجح التشفير (Python 2)! الملف الحالي: plugin.pyc"
        fi
    fi
else
    echo "⚠️ لم يتم العثور على plugin.py"
fi

