# -*- coding: utf-8 -*-
# ================================================================================
# تم تطوير هذا البلجن بواسطة خالد - نسخة احترافية ذهبية شاملة (Gold Edition)
# KHALED WORLD - CLOUD&MORE PANEL PRO v2.8 (LOGO & STABLE EDITION)
# ================================================================================

from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.Console import Console
from Components.ActionMap import ActionMap
from Components.MenuList import MenuList
from Components.Label import Label
from Components.Sources.StaticText import StaticText
import os

# ================================================================================
# قسم التعريفات والروابط (Global Configuration & Remote Links) 
# ================================================================================

LINK_NCAM = "https://github.com/KhaledAli65/emu/raw/refs/heads/main/enigma2-plugin-softcams-ncam.ipk"
LINK_OSCAM = "https://github.com/KhaledAli65/emu/raw/refs/heads/main/enigma2-plugin-softcams-oscam-emu.ipk"
URL_CHANNELS = "https://github.com/KhaledAli65/novaler/raw/refs/heads/main/khaled_fullsat.tar.gz"
URL_PICON = "https://dl.dropboxusercontent.com/scl/fi/2mx5dcqyg6got4g1866gu/picon.zip?rlkey=neqnxp9uzil056v5d63xv0pfe&st=mrqp1r27&dl=0"
URL_EPG = "https://github.com/KhaledAli65/novaler/raw/main/epg.tar.gz"
URL_SATXML = "https://raw.githubusercontent.com/oe-alliance/oe-alliance-tuxbox-common/master/src/satellites.xml"
URL_METRIX = "https://github.com/KhaledAli65/novaler/raw/refs/heads/main/MyMetrixLiteBackup.dat"
LINK_AJPANEL = "https://raw.githubusercontent.com/biko-73/AJPANEL/main/ajpanel.ipk"
LINK_MULTISTALKER = "https://github.com/emilnabil/multistalker/raw/main/multistalker.ipk"

# مسارات الـ HDD الأصلية من ملفك
HDD_BACKUP_PATH = "/media/hdd/Script_New_Edition/1/"
PATH_SCRIPTS_1 = "/media/hdd/Script_New_Edition/1/"
PATH_IPKS_2 = "/media/hdd/Script_New_Edition/2/"
LOGO_PATH = "/usr/lib/enigma2/python/Plugins/Extensions/MySimplePanel/logo.png"

# ================================================================================
# إضافة: متصفح الملفات الفردية (للمجلدات 1 و 2)
# ================================================================================
class KhaledFileBrowser(Screen):
    skin = """
    <screen name="KhaledFileBrowser" position="center,center" size="1100,750" title="Khaled File Browser" backgroundColor="#101010">
        <eLabel position="0,0" size="1100,90" backgroundColor="#2c3e50" zPosition="-1" />
        <ePixmap pixmap="%s" position="20,15" size="60,60" alphatest="on" />
        <widget name="title_label" position="100,20" size="970,50" font="Regular;40" foregroundColor="#ffffff" transparent="1" />
        <widget name="menu" position="50,120" size="1000,500" itemHeight="80" font="Regular;34" selectionColor="#2980b9" transparent="1" />
        <eLabel position="0,660" size="1100,90" backgroundColor="#1a252f" zPosition="-1" />
    </screen>""" % LOGO_PATH
    def __init__(self, session, path, file_ext):
        Screen.__init__(self, session)
        self.path, self.file_ext = path, file_ext
        self.list = []
        self["menu"] = MenuList(self.list)
        self["title_label"] = Label("اختر ملفاً واحداً للتنفيذ")
        self["actions"] = ActionMap(["OkCancelActions"], {"ok": self.go, "cancel": self.close}, -1)
        self.loadFiles()
    def loadFiles(self):
        self.list = []
        if os.path.exists(self.path):
            for f in sorted(os.listdir(self.path)):
                if f.endswith(self.file_ext): self.list.append((f, f))
        if not self.list: self.list.append(("⚠️ المجلد فارغ", "none"))
        self["menu"].setList(self.list)
    def go(self):
        sel = self["menu"].getCurrent()
        if sel and sel[1] != "none":
            p = os.path.join(self.path, sel[1])
            cmd = "chmod 755 '%s' && bash '%s'" % (p, p) if self.file_ext == ".sh" else "opkg install '%s'" % p
            self.session.open(Console, title="Executing: %s" % sel[1], cmdlist=[cmd])

# ================================================================================
# 1. شاشة إدارة السكينات (Skins Manager)
# ================================================================================
class SkinsManager(Screen):
    skin = """
    <screen name="SkinsManager" position="center,center" size="1200,820" title="Khaled Skins Pro" backgroundColor="#101010">
        <eLabel position="0,0" size="1200,100" backgroundColor="#8e44ad" zPosition="-1" />
        <ePixmap pixmap="%s" position="20,10" size="80,80" alphatest="on" />
        <widget name="title_label" position="120,20" size="1040,60" font="Regular;45" foregroundColor="#ffffff" transparent="1" halign="left" />
        <widget name="menu" position="60,140" size="1080,560" itemHeight="90" scrollbarMode="showOnDemand" transparent="1" font="Regular;38" selectionColor="#9b59b6" />
        <eLabel position="0,730" size="1200,90" backgroundColor="#2c3e50" zPosition="-1" />
    </screen>""" % LOGO_PATH
    def __init__(self, session):
        Screen.__init__(self, session)
        self.list = [
            ("🎨 تشغيل كافة سكريبتات السكينات (.sh) من HDD", "run_sh"),
            ("📁 تثبيت ملفات السكينات (.ipk) من HDD", "run_ipk"),
            ("✨ استعادة باك اب متركس لايت (Metrix Backup)", "metrix_back"),
            ("📥 تحميل سكين Metrix الافتراضي من السيرفر", "install_metrix"),
            ("↩ عودة للقائمة السابقة (Back)", "exit")
        ]
        self["menu"] = MenuList(self.list)
        self["title_label"] = Label("قسم السكينات والمظهر - Skins")
        self["actions"] = ActionMap(["OkCancelActions"], {"ok": self.run, "cancel": self.close}, -1)
    def run(self):
        p = self["menu"].getCurrent()
        if p:
            if p[1] == "exit": self.close()
            elif p[1] == "run_sh":
                cmd = "chmod 755 %s*.sh && for f in %s*.sh; do bash \"$f\"; done" % (HDD_BACKUP_PATH, HDD_BACKUP_PATH)
                self.session.open(Console, cmdlist=[cmd])
            elif p[1] == "run_ipk": self.session.open(Console, cmdlist=["opkg install %s*.ipk" % HDD_BACKUP_PATH])
            elif p[1] == "metrix_back": self.session.open(Console, cmdlist=["wget %s -O /etc/enigma2/MyMetrixLiteBackup.dat" % URL_METRIX])
            elif p[1] == "install_metrix": self.session.open(Console, cmdlist=["opkg install enigma2-plugin-skins-metrix-atv"])

# ================================================================================
# 2. شاشة إدارة البلاجن (Plugins Manager)
# ================================================================================
class PluginsManager(Screen):
    skin = """
    <screen name="PluginsManager" position="center,center" size="1200,820" title="Khaled Plugins" backgroundColor="#101010">
        <eLabel position="0,0" size="1200,100" backgroundColor="#2980b9" zPosition="-1" />
        <ePixmap pixmap="%s" position="20,10" size="80,80" alphatest="on" />
        <widget name="title_label" position="120,20" size="1040,60" font="Regular;45" foregroundColor="#ffffff" transparent="1" halign="left" />
        <widget name="menu" position="60,140" size="1080,560" itemHeight="90" font="Regular;38" selectionColor="#3498db" />
        <eLabel position="0,730" size="1200,90" backgroundColor="#2c3e50" zPosition="-1" />
    </screen>""" % LOGO_PATH
    def __init__(self, session):
        Screen.__init__(self, session)
        self.list = [
            ("🔌 AjPanel (أحدث إصدار - سيرفر)", "ajpanel"),
            ("🔌 MultiStalker (أحدث إصدار - سيرفر)", "stalker"),
            ("📜 اختيار سكريبت محدد من المجلد 1", "sh_single"),
            ("📁 اختيار ملف IPK محدد من المجلد 2", "ipk_single"),
            ("📜 تشغيل كافة سكريبتات الـ SH من HDD", "sh_all"),
            ("📁 تثبيت كافة ملفات الـ IPK من HDD", "ipk_all"),
            ("↩ عودة (Back)", "exit")
        ]
        self["menu"] = MenuList(self.list)
        self["title_label"] = Label("البلاجن والسكريبتات - Plugins")
        self["actions"] = ActionMap(["OkCancelActions"], {"ok": self.run, "cancel": self.close}, -1)
    def run(self):
        p = self["menu"].getCurrent()
        if p:
            if p[1] == "exit": self.close()
            elif p[1] == "ajpanel": self.session.open(Console, cmdlist=["wget %s -O /tmp/p.ipk && opkg install /tmp/p.ipk" % LINK_AJPANEL])
            elif p[1] == "stalker": self.session.open(Console, cmdlist=["wget %s -O /tmp/s.ipk && opkg install /tmp/s.ipk" % LINK_MULTISTALKER])
            elif p[1] == "sh_single": self.session.open(KhaledFileBrowser, PATH_SCRIPTS_1, ".sh")
            elif p[1] == "ipk_single": self.session.open(KhaledFileBrowser, PATH_IPKS_2, ".ipk")
            elif p[1] == "sh_all": self.session.open(Console, cmdlist=["chmod 755 %s*.sh && for f in %s*.sh; do bash \"$f\"; done" % (HDD_BACKUP_PATH, HDD_BACKUP_PATH)])
            elif p[1] == "ipk_all": self.session.open(Console, cmdlist=["opkg install %s*.ipk" % HDD_BACKUP_PATH])

# ================================================================================
# 3. شاشة إدارة الأدوات (Tools Manager)
# ================================================================================
class ToolsManager(Screen):
    skin = """<screen name="ToolsManager" position="center,center" size="1200,820" title="Khaled Tools" backgroundColor="#101010"><eLabel position="0,0" size="1200,100" backgroundColor="#d35400" zPosition="-1" /><ePixmap pixmap="%s" position="20,10" size="80,80" alphatest="on" /><widget name="title_label" position="120,20" size="1040,60" font="Regular;45" foregroundColor="#ffffff" transparent="1" halign="left" /><widget name="menu" position="60,140" size="1080,560" itemHeight="90" font="Regular;38" selectionColor="#e67e22" transparent="1" /><eLabel position="0,730" size="1200,90" backgroundColor="#2c3e50" zPosition="-1" /></screen>""" % LOGO_PATH
    def __init__(self, session):
        Screen.__init__(self, session)
        self.list = [("📡 ملف قنوات خالد الكامل (Full Sat)", "channels"), ("🖼 البيكونات (Picons)", "picon"), ("📅 دليل البرامج (EPG)", "epg"), ("🌍 ملف الأقمار (Satellites.xml)", "satxml"), ("↩ عودة", "exit")]
        self["menu"] = MenuList(self.list)
        self["title_label"] = Label("أدوات الصيانة والدعم")
        self["actions"] = ActionMap(["OkCancelActions"], {"ok": self.run, "cancel": self.close}, -1)
    def run(self):
        p = self["menu"].getCurrent()
        if p[1] == "exit": self.close()
        else:
            cmd = ""
            if p[1] == "channels": cmd = "wget %s -O /tmp/c.tar.gz && tar -xzf /tmp/c.tar.gz -C /etc/enigma2/ && killall -9 enigma2" % URL_CHANNELS
            elif p[1] == "picon": cmd = "wget '%s' -O /tmp/p.zip && unzip -o /tmp/p.zip -d /media/hdd/" % URL_PICON
            elif p[1] == "epg": cmd = "wget %s -O /tmp/e.tar.gz && tar -xzf /tmp/e.tar.gz -C /etc/enigma2/" % URL_EPG
            elif p[1] == "satxml": cmd = "wget %s -O /etc/tuxbox/satellites.xml" % URL_SATXML
            self.session.open(Console, cmdlist=[cmd])

# ================================================================================
# 4. شاشة إدارة الإيموهات (Emu Manager)
# ================================================================================
class EmuManager(Screen):
    skin = """<screen name="EmuManager" position="center,center" size="1200,820" title="Emu Manager" backgroundColor="#101010"><eLabel position="0,0" size="1200,90" backgroundColor="#27ae60" zPosition="-1" /><ePixmap pixmap="%s" position="20,5" size="80,80" alphatest="on" /><widget name="title_label" position="120,25" size="1040,60" font="Regular;42" foregroundColor="#ffffff" transparent="1" halign="left" /><widget name="menu" position="60,140" size="1080,550" itemHeight="80" transparent="1" font="Regular;36" selectionColor="#1e8449" /><eLabel position="0,730" size="1200,90" backgroundColor="#2c3e50" zPosition="-1" /></screen>""" % LOGO_PATH
    def __init__(self, session):
        Screen.__init__(self, session)
        self.list = [("📥 Install Ncam", "ncam"), ("📥 Install Oscam-Emu", "oscam"), ("↩ Back", "exit")]
        self["menu"] = MenuList(self.list)
        self["title_label"] = Label("إيموهات عالم خالد")
        self["actions"] = ActionMap(["OkCancelActions"], {"ok": self.run, "cancel": self.close}, -1)
    def run(self):
        p = self["menu"].getCurrent()
        if p[1] == "exit": self.close()
        else:
            url = LINK_NCAM if p[1] == "ncam" else LINK_OSCAM
            cmd = "wget %s -O /tmp/e.ipk && opkg install /tmp/e.ipk && rm -f /tmp/e.ipk" % url
            self.session.open(Console, cmdlist=[cmd])

# ================================================================================
# 5. عالم خالد والشاشة الرئيسية
# ================================================================================
class KhaledWorld(Screen):
    skin = """<screen name="KhaledWorld" position="center,center" size="1200,820" title="Khaled World" backgroundColor="#101010"><eLabel position="0,0" size="1200,100" backgroundColor="#c0392b" zPosition="-1" /><ePixmap pixmap="%s" position="20,10" size="80,80" alphatest="on" /><widget name="title_label" position="120,20" size="1040,60" font="Regular;45" foregroundColor="#ffffff" transparent="1" halign="left" /><widget name="menu" position="60,140" size="1080,560" itemHeight="95" font="Regular;40" selectionColor="#e74c3c" transparent="1" /><eLabel position="0,730" size="1200,90" backgroundColor="#2c3e50" zPosition="-1" /></screen>""" % LOGO_PATH
    def __init__(self, session):
        Screen.__init__(self, session)
        self.list = [("📟 قسم الإيموهات", "emu"), ("🔧 قسم الأدوات", "tools"), ("📁 قسم البلاجن", "plugins"), ("🎨 قسم السكينات", "skins"), ("↩ عودة", "exit")]
        self["menu"] = MenuList(self.list)
        self["title_label"] = Label("عالم خالد - Khaled World Hub")
        self["actions"] = ActionMap(["OkCancelActions"], {"ok": self.go, "cancel": self.close}, -1)
    def go(self):
        p = self["menu"].getCurrent()
        if p[1] == "emu": self.session.open(EmuManager)
        elif p[1] == "tools": self.session.open(ToolsManager)
        elif p[1] == "plugins": self.session.open(PluginsManager)
        elif p[1] == "skins": self.session.open(SkinsManager)
        elif p[1] == "exit": self.close()

class MainCorePanel(Screen):
    skin = """<screen name="MainCorePanel" position="center,center" size="1200,820" title="Elite Panel Pro" backgroundColor="#101010"><eLabel position="0,0" size="1200,120" backgroundColor="#1a252f" zPosition="-1" /><ePixmap pixmap="%s" position="40,20" size="80,80" alphatest="on" /><widget name="title_label" position="140,30" size="1020,60" font="Regular;50" foregroundColor="#ffffff" halign="center" transparent="1" /><widget name="menu" position="80,180" size="1040,460" itemHeight="100" font="Regular;42" selectionColor="#2980b9" transparent="1" /><eLabel position="0,730" size="1200,90" backgroundColor="#2c3e50" zPosition="-1" /><widget name="status" position="30,750" size="1140,50" font="Regular;34" halign="center" foregroundColor="#f1c40f" transparent="1" /></screen>""" % LOGO_PATH
    def __init__(self, session):
        Screen.__init__(self, session)
        self.list = [("🌍 عالم خالد Edition", "khaled"), ("⟳ تحديث النظام", "update"), ("⚙ إعادة تشغيل", "reboot")]
        self["menu"] = MenuList(self.list)
        self["title_label"] = Label("لوحة تحكم خالد - Elite Panel Pro")
        self["status"] = Label("إصدار v2.8 المستقر - تم إضافة الشعار بنجاح")
        self["actions"] = ActionMap(["OkCancelActions"], {"ok": self.run, "cancel": self.close}, -1)
    def run(self):
        p = self["menu"].getCurrent()
        if p[1] == "khaled": self.session.open(KhaledWorld)
        elif p[1] == "update": self.session.open(Console, cmdlist=["opkg update && opkg upgrade && reboot"])
        elif p[1] == "reboot": os.system("reboot")

def main(session, **kwargs):
    session.open(MainCorePanel)

def Plugins(**kwargs):
    desc = "خالد - النسخة الاحترافية v2.8 - تدعم كافة الأدوات مع شعار مخصص واختيار ملفات HDD"
    return [PluginDescriptor(name="CLOUD&MORE Panel Pro", description=desc, where=PluginDescriptor.WHERE_PLUGINMENU,icon=LOGO_PATH,fnc=main)]

